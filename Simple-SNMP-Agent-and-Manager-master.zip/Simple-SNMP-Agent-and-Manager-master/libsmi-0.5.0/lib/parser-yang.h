

#ifndef _PARSER_YANG_H
#define _PARSER_YANG_H

#include <stdio.h>

#include "yang-data.h"



#define YYERROR_VERBOSE



extern int yangparse();



#endif /* _PARSER_YANG_H */

